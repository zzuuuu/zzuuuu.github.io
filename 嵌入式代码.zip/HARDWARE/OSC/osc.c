#include"osc.h"

void clear_point(u16 num)//������ʾ����ǰ��
{
	u16 index_clear_lie = 0; 
	POINT_COLOR = BLACK ;
	for(index_clear_lie = 1;index_clear_lie < 400;index_clear_lie++)
	{		
		LCD_DrawPoint(num,index_clear_lie );
	}
	if(!(num%50))//�ж�hang�Ƿ�Ϊ50�ı��� ���е�
	{
		for(index_clear_lie = 10;index_clear_lie < 400;index_clear_lie += 10)
		{		
			LCD_Fast_DrawPoint(num ,index_clear_lie,WHITE );
		}
	}
	if(!(num%10))//�ж�hang�Ƿ�Ϊ10�ı��� ���е�
	{
		for(index_clear_lie = 50;index_clear_lie <400;index_clear_lie += 50)
		{		
			LCD_Fast_DrawPoint(num ,index_clear_lie,WHITE );
		}
	}	
	POINT_COLOR = YELLOW;	
}
void DrawOscillogram(u16 *buff)//������ͼ
{
	static u16 Ypos1 = 0,Ypos2 = 0;
	u16 Yinit=100;
	u16 i = 0;
	POINT_COLOR = YELLOW;
	for(i = 1;i < 512;i++)//�洢FFT��ֵ
	{
		buff[i] = fft_outputbuf[i];
	}
	for(i = 1;i < 512;i++)
	{
		clear_point(i );	
		Ypos2 = 400-(buff[i]/200);//ת������
		//Ypos2 = Ypos2 * bei;
		if(Ypos2 >700)
			Ypos2 =700; //������Χ����ʾ
		LCD_DrawLine (i ,Ypos1 , i+1 ,Ypos2);
		Ypos1 = Ypos2 ;
	}
    Ypos1 = 0;	
}
void Set_BackGround(void)
{
	POINT_COLOR = YELLOW;
    LCD_Clear(BLACK);
	LCD_DrawRectangle(0,0,700,400);//����
	//LCD_DrawLine(0,220,700,220);//����
	//LCD_DrawLine(350,20,350,420);//����
	//POINT_COLOR = WHITE;
	//BACK_COLOR = DARKBLUE;
	//LCD_ShowString(330,425,210,24,24,(u8*)"vpp=");	
}
void Lcd_DrawNetwork(void)
{
	u16 index_y = 0;
	u16 index_x = 0;	
	
    //���е�	
	for(index_x = 50;index_x < 700;index_x += 50)
	{
		for(index_y = 10;index_y < 400;index_y += 10)
		{
			LCD_Fast_DrawPoint(index_x,index_y,WHITE);	
		}
	}
	//���е�
	for(index_y = 50;index_y < 400;index_y += 50)
	{
		for(index_x = 10;index_x < 700;index_x += 10)
		{
			LCD_Fast_DrawPoint(index_x,index_y,WHITE);	
		}
	}
}

u16 Get_FFT_Max(u16* buf,u16 dona)
{
	u16 max=0,i;
	int j;
		for(i = (dona-20);i < (dona+20);i++)//�洢FFT��ֵ
	{
		if(max<fft_outputbuf[i])
		{
			max=fft_outputbuf[i];
			j=i;
		}
	}

	return j;
	
}